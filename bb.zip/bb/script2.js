document.getElementById('business-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent form submission

    const businessType = document.getElementById('business-type').value;
    const businessOutput = document.getElementById('business-output');
    const videoLinksList = document.getElementById('video-links-list');

    // Set selected business type text
    businessOutput.textContent = businessType.charAt(0).toUpperCase() + businessType.slice(1).replace(/-/g, ' ');

    // Clear previous links
    videoLinksList.innerHTML = '';

    let youtubeLinks;

    switch (businessType) {  // Use businessType instead of selectedBusiness
        case 'sole-proprietorship':
            youtubeLinks = [
                'https://youtu.be/b-n4u3HcXpo', // Sole Proprietorship Basics
                'https://youtu.be/VF8nN3erAIM', // Starting a Sole Proprietorship
                'https://youtu.be/6NrvX3ifofc', // Pros and Cons of Sole Proprietorship
                'https://youtu.be/tg_eJ3qVBhw', // Sole Proprietorship Taxes Explained
                'https://youtu.be/1XrzwsCGycM'  // How to Pay Yourself as a Sole Proprietor
            ];
            break;
        case 'partnership':
            youtubeLinks = [
                'https://youtu.be/fG_NBTeNN2s', // How To Make A Business Partnership Work
                'https://youtu.be/Wxg678eIRNQ', // 10 Types of Business Partners
                'https://youtu.be/RY0Bc-I1bAU', // How to Choose the Right Business Partner
                'https://youtu.be/4NqVrn67k5k', // Partnership Agreements Explained
                'https://youtu.be/2n7gNIrN--M'  // How To Build Successful Business Partnerships
            ];
            break;
        case 'llc':
            youtubeLinks = [
                'https://youtu.be/tVaZ_BpV1vc', // What is an LLC?
                'https://youtu.be/u1WGBoIcK3A', // How to Form an LLC
                'https://youtu.be/gxIN04DdNHc', // LLC vs. Sole Proprietorship
                'https://youtu.be/JibRkMqhih8', // LLC Tax Benefits
                'https://youtu.be/9RNlz_pmno8'  // Maintaining Your LLC
            ];
            break;
        case 'corporation':
            youtubeLinks = [
                'https://youtu.be/wOq2XaxY214', // Understanding Corporations
                'https://youtu.be/N8ntMu196QE', // C-Corp vs. S-Corp
                'https://youtu.be/5cM7zo1V5Jo', // How to Start a Corporation
                'https://youtu.be/wtMORWO5h9Y', // Corporate Structure Explained
                'https://youtu.be/TNYUtmTBr9M'  // Corporate Taxes Overview
            ];
            break;
        // Add cases for other business types as needed
		     break;
        case 'franchise':
            businessText = 'Franchise';
            youtubeLinks = [
                'https://youtu.be/Kp-0AhgBiDg', // What is a Franchise?
                'https://youtu.be/6hgnvpdteZA', // How to Start a Franchise
                'https://youtu.be/VrQa-CWvgv4', // Pros and Cons of Franchising
                'https://youtu.be/stbEYg4Z2mw', // Franchise Business Plan
                'https://youtu.be/4ajmfzj9G1g'  // Franchise Marketing Strategies
            ];
            break;
        case 'home-based-business':
            businessText = 'Home-Based Business';
            youtubeLinks = [
                'https://youtu.be/YplnEkBIk0U', // Starting a Home-Based Business
                'https://youtu.be/GRDUJyCqAzM', // Pros and Cons of Home-Based Businesses
                'https://youtu.be/G0dzLanYW1E', // Best Home Business Ideas
                'https://youtu.be/o3qNszjzkdQ', // Managing a Home-Based Business
                'https://youtu.be/hPTqHt3IV08'  // Legal Considerations for Home Businesses
            ];
            break;
        case 'e-commerce':
            businessText = 'E-commerce Business';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=sWs6YbIMuEw', // How to Start an E-commerce Business
                'https://www.youtube.com/watch?v=7s1gJWmXMWo', // E-commerce Marketing Strategies
                'https://www.youtube.com/watch?v=k-9G78FgKek', // Dropshipping vs. E-commerce
                'https://www.youtube.com/watch?v=ql8gBQvDE0E', // Building an E-commerce Website
                'https://www.youtube.com/watch?v=4U8Se-c-t6I'  // E-commerce Business Plan Tips
            ];
            break;
        case 'retail':
            businessText = 'Brick-and-Mortar Retail';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=9oFgy2VdzE8', // Starting a Retail Business
                'https://www.youtube.com/watch?v=-K8yO3fK-Zs', // Retail Marketing Strategies
                'https://www.youtube.com/watch?v=fC-1-kq2RMo', // Retail Store Layout Ideas
                'https://www.youtube.com/watch?v=UXQ17X4rR8s', // Managing a Retail Business
                'https://www.youtube.com/watch?v=aY1vnOsZ2Xw'  // Common Retail Challenges
            ];
            break;
			case 'service-based':
            businessText = 'Service-Based Business';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=EO0qxH8OPjY', // Starting a Service-Based Business
                'https://www.youtube.com/watch?v=yEslWweipVI', // Service-Based Business Ideas
                'https://www.youtube.com/watch?v=4H2P1GcdSo0', // Marketing a Service Business
                'https://www.youtube.com/watch?v=5Y3WLD4DqVg', // Common Mistakes in Service-Based Businesses
                'https://www.youtube.com/watch?v=0M3cGo3k82c'  // Pricing Your Services
            ];
            break;
        case 'freelancing':
            businessText = 'Freelancing';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=pEZz30TfjCA', // How to Start Freelancing
                'https://www.youtube.com/watch?v=sHPlkjFEeH4', // Freelancing Tips for Beginners
                'https://www.youtube.com/watch?v=p53xt-AeFlE', // Finding Freelance Clients
                'https://www.youtube.com/watch?v=rfjNSCmYPfI', // Setting Your Freelance Rates
                'https://www.youtube.com/watch?v=gpMWC62Mz9Q'  // Managing Freelance Workload
            ];
            break;
        case 'consulting':
            businessText = 'Consulting Business';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=CCf7W89PKV4', // Starting a Consulting Business
                'https://www.youtube.com/watch?v=bwXZT-0XfTQ', // How to Find Consulting Clients
                'https://www.youtube.com/watch?v=OiYbNVFZSOY', // Consulting Business Models
                'https://www.youtube.com/watch?v=2FlU1Qwwgf8', // Pricing Your Consulting Services
                'https://www.youtube.com/watch?v=He_Hj2nHI6g'  // Building Your Consulting Brand
            ];
            break;
        case 'dropshipping':
            businessText = 'Dropshipping Business';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=Vh-5V_0jMoo', // How to Start Dropshipping
                'https://www.youtube.com/watch?v=8h1iT3WfokE', // Finding Dropshipping Suppliers
                'https://www.youtube.com/watch?v=p3kqG99dr5E', // Marketing Your Dropshipping Store
                'https://www.youtube.com/watch?v=CoCBU5S-4NA', // Common Mistakes in Dropshipping
                'https://www.youtube.com/watch?v=mgyWm90ptwY'  // Scaling Your Dropshipping Business
            ];
            break;
        case 'food-truck':
            businessText = 'Food Truck';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=kaXMBI6FLjY', // Starting a Food Truck Business
                'https://www.youtube.com/watch?v=MYGy32gZSyY', // Food Truck Marketing Strategies
                'https://www.youtube.com/watch?v=oi9Ub6NOuhM', // Food Truck Business Plan
                'https://www.youtube.com/watch?v=FvFYFeTFoo0', // Food Truck Equipment You Need
                'https://www.youtube.com/watch?v=YJ3xzqCB8Yw'  // Navigating Food Truck Regulations
            ];
            break;
        case 'cafe':
            businessText = 'Café or Coffee Shop';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=7N9fM_C2RrM', // How to Start a Coffee Shop
                'https://www.youtube.com/watch?v=mrD1U19IloA', // Coffee Shop Marketing Ideas
                'https://www.youtube.com/watch?v=c_B8NGZ6bgI', // Coffee Shop Menu Ideas
                'https://www.youtube.com/watch?v=k8FuMcDcdx0', // Cafe Business Plan
                'https://www.youtube.com/watch?v=sIwnzF30bMs'  // Managing a Coffee Shop
            ];
            break;
        case 'bakery':
            businessText = 'Bakery';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=Lg8r66P8Oog', // Starting a Bakery Business
                'https://www.youtube.com/watch?v=kv1gsu3D5Ng', // Bakery Marketing Strategies
                'https://www.youtube.com/watch?v=v1jT0O0YwQA', // Bakery Menu Ideas
                'https://www.youtube.com/watch?v=izU0kALuU_M', // Managing a Bakery
                'https://www.youtube.com/watch?v=Tf7lV9gI7oA'  // Common Bakery Challenges
            ];
            break;
        case 'boutique':
            businessText = 'Boutique';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=AiU8df7T--U', // How to Start a Boutique
                'https://www.youtube.com/watch?v=q6HnqD_oIKg', // Boutique Marketing Strategies
                'https://www.youtube.com/watch?v=FK48iBBfrGk', // Boutique Inventory Management
                'https://www.youtube.com/watch?v=39zpL2O2gk8', // Fashion Trends for Boutiques
                'https://www.youtube.com/watch?v=UN2brQ0kLzE'  // Managing a Successful Boutique
            ];
            break;
        case 'event-planning':
            businessText = 'Event Planning';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=0D_zg7KgndM', // Starting an Event Planning Business
                'https://www.youtube.com/watch?v=ePlIf9XHKbA', // Event Planning Tips
                'https://www.youtube.com/watch?v=dD9yb3MFPSs', // Marketing Your Event Planning Services
                'https://www.youtube.com/watch?v=UChEl2Z9-6Q', // Event Planning Business Plan
                'https://www.youtube.com/watch?v=6SWjhtNU3L8'  // Common Event Planning Mistakes
            ];
            break;
        case 'photography':
            businessText = 'Photography Business';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=b2n8gvk5oMQ', // How to Start a Photography Business
                'https://www.youtube.com/watch?v=g1X4_XK_CVY', // Photography Marketing Tips
                'https://www.youtube.com/watch?v=j0jT2k7xK5c', // Building a Photography Portfolio
                'https://www.youtube.com/watch?v=y7_3W4jQ6g', // Pricing Your Photography Services
                'https://www.youtube.com/watch?v=K2dVoIKi4V8'  // Photography Equipment Essentials
            ];
            break;
        case 'pet-care':
            businessText = 'Pet Grooming or Pet Sitting';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=l2HrK0Q5iDo', // Starting a Pet Care Business
                'https://www.youtube.com/watch?v=YOi7wH2sfVw', // Pet Sitting Tips
                'https://www.youtube.com/watch?v=gXH6-5JHDcQ', // Pet Grooming Basics
                'https://www.youtube.com/watch?v=2wv6EDvW7sA', // Marketing Your Pet Care Business
                'https://www.youtube.com/watch?v=5Xb8nVg2I5o'  // Pet Care Business Plan
            ];
            break;
        case 'landscaping':
            businessText = 'Landscaping or Lawn Care';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=G4eT7gDgFpo', // How to Start a Landscaping Business
                'https://www.youtube.com/watch?v=bwIEuDs5gfg', // Landscaping Business Marketing
                'https://www.youtube.com/watch?v=sRWVhWxHqcg', // Landscape Design Basics
                'https://www.youtube.com/watch?v=yFf1NdoSOQ0', // Pricing Your Landscaping Services
                'https://www.youtube.com/watch?v=Y2lBOHZKiy8'  // Managing a Landscaping Business
            ];
            break;
        case 'cleaning':
            businessText = 'Cleaning Services';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=ZxqTtGZ_nlY', // Starting a Cleaning Business
                'https://www.youtube.com/watch?v=UNtHoS3pXx8', // Cleaning Business Marketing Strategies
                'https://www.youtube.com/watch?v=44uAnD3auQA', // Pricing Your Cleaning Services
                'https://www.youtube.com/watch?v=y31uqFzJv8c', // Cleaning Business Plan
                'https://www.youtube.com/watch?v=szJmTzKDruo'  // Common Cleaning Business Challenges
            ];
            break;
        case 'real-estate':
            businessText = 'Real Estate Agency';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=jGchC_vB6Mg', // Starting a Real Estate Business
                'https://www.youtube.com/watch?v=WTqfLybPrsM', // Real Estate Marketing Strategies
                'https://www.youtube.com/watch?v=MT6dVqZ2V9E', // Real Estate Business Plan
                'https://www.youtube.com/watch?v=Ls66U5vij1I', // Real Estate Investment Tips
                'https://www.youtube.com/watch?v=kUpAB2MFnjs'  // Managing a Real Estate Agency
            ];
            break;
        case 'tutoring':
            businessText = 'Tutoring Services';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=2yeNPiFXTBU', // How to Start a Tutoring Business
                'https://www.youtube.com/watch?v=1JZuQdRpm5Y', // Finding Tutoring Clients
                'https://www.youtube.com/watch?v=m-J38uh3FOU', // Marketing Your Tutoring Services
                'https://www.youtube.com/watch?v=vUwm8pmU51U', // Pricing Your Tutoring Services
                'https://www.youtube.com/watch?v=lXMBtROgrI8'  // Tutoring Business Plan
            ];
            break;
        case 'fitness':
            businessText = 'Fitness Trainer or Studio';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=p08XKtJ5yyg', // Starting a Fitness Business
                'https://www.youtube.com/watch?v=c1FbpwM2eok', // Marketing Your Fitness Services
                'https://www.youtube.com/watch?v=gU-0L6ZDlD0', // Finding Fitness Clients
                'https://www.youtube.com/watch?v=Xt0jH3_fOM4', // Pricing Your Fitness Services
                'https://www.youtube.com/watch?v=aN4HG1FtbpY'  // Managing a Fitness Studio
            ];
            break;
        case 'salon':
            businessText = 'Beauty Salon or Barber Shop';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=ICgVHvB2P_Q', // Starting a Beauty Salon
                'https://www.youtube.com/watch?v=b4D5h0Fr3pM', // Salon Marketing Tips
                'https://www.youtube.com/watch?v=zz2nlA9v7_Q', // Salon Management Basics
                'https://www.youtube.com/watch?v=2W3ST0gBo4E', // Pricing Your Salon Services
                'https://www.youtube.com/watch?v=1qvMZ0GmT6Y'  // Common Salon Challenges
            ];
            break;
        case 'daycare':
            businessText = 'Daycare or Creche';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=XYFboF2eH_E', // Starting a Daycare Business
                'https://www.youtube.com/watch?v=aO63Sr-HnMs', // Daycare Marketing Strategies
                'https://www.youtube.com/watch?v=t4jPPN1nT48', // Daycare Licensing and Regulations
                'https://www.youtube.com/watch?v=vjqP1At7X1I', // Pricing Your Daycare Services
                'https://www.youtube.com/watch?v=pwL4KnmbUok'  // Managing a Daycare Center
            ];
            break;
        case 'it-support':
            businessText = 'IT Support or Repair Services';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=Q8_WT8W1UO8', // How to Start an IT Support Business
                'https://www.youtube.com/watch?v=uEfTYyW0E4s', // IT Support Marketing Strategies
                'https://www.youtube.com/watch?v=_Qh7EXZoBTs', // Pricing IT Support Services
                'https://www.youtube.com/watch?v=6uq__hN1w3w', // IT Support Business Plan
                'https://www.youtube.com/watch?v=uCh3WcNH7bs'  // Common IT Support Challenges
            ];
            break;
        case 'app-development':
            businessText = 'App Development';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=lEvhOwDqCRU', // How to Start an App Development Business
                'https://www.youtube.com/watch?v=Z5B6k3Fr48M', // App Development Marketing Tips
                'https://www.youtube.com/watch?v=mnvoM-FwzD4', // Building Your App Portfolio
                'https://www.youtube.com/watch?v=YcZkd2Niw58', // Pricing Your App Development Services
                'https://www.youtube.com/watch?v=G5iyvGm4pAE'  // Common App Development Challenges
            ];
            break;
        case 'handyman':
            businessText = 'Handyman Services';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=6ug1hOIfS2o', // Starting a Handyman Business
                'https://www.youtube.com/watch?v=fZCmH44LwuA', // Handyman Marketing Strategies
                'https://www.youtube.com/watch?v=sL8DsmEyn2U', // Pricing Your Handyman Services
                'https://www.youtube.com/watch?v=RfD1lC9Dr2U', // Handyman Business Plan
                'https://www.youtube.com/watch?v=e6Y0f4B4eD0'  // Common Handyman Challenges
            ];
            break;
        case 'digital-marketing':
            businessText = 'Digital Marketing Agency';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=7HhF0bK2k0s', // How to Start a Digital Marketing Agency
                'https://www.youtube.com/watch?v=fI5Z0g1W6_Q', // Digital Marketing Strategies
                'https://www.youtube.com/watch?v=zZp0bmgS1ZI', // Pricing Your Digital Marketing Services
                'https://www.youtube.com/watch?v=ME5Rr8hU8Aw', // Building Your Digital Marketing Portfolio
                'https://www.youtube.com/watch?v=q7TLN92b2pI'  // Common Digital Marketing Challenges
            ];
            break;
        case 'car-wash':
            businessText = 'Car Wash';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=VVSt61DWuaI', // How to Start a Car Wash Business
                'https://www.youtube.com/watch?v=2Jh3r_GiCoU', // Car Wash Marketing Strategies
                'https://www.youtube.com/watch?v=eS5mRpE4VVw', // Car Wash Pricing Guide
                'https://www.youtube.com/watch?v=pI-JZMKdG6M', // Car Wash Business Plan
                'https://www.youtube.com/watch?v=_ke89W3_JgQ'  // Common Car Wash Challenges
            ];
            break;
        case 'social-media':
            businessText = 'Social Media Management';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=o0gDFDTtRmY', // How to Start a Social Media Management Business
                'https://www.youtube.com/watch?v=RJ9oYKrk9n8', // Social Media Marketing Tips
                'https://www.youtube.com/watch?v=tBL2YgqeQHs', // Pricing Your Social Media Services
                'https://www.youtube.com/watch?v=If2cCrkgLx4', // Building Your Social Media Portfolio
                'https://www.youtube.com/watch?v=lGm7C72lsb0'  // Common Social Media Management Challenges
            ];
            break;
        case 'subscription-box':
            businessText = 'Subscription Box Service';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=Gf2s9t7YI3g', // How to Start a Subscription Box Business
                'https://www.youtube.com/watch?v=43F7DeeODqs', // Subscription Box Marketing Strategies
                'https://www.youtube.com/watch?v=Vva8dpuLUO0', // Pricing Your Subscription Box Service
                'https://www.youtube.com/watch?v=c3cPOGxIHBo', // Managing a Subscription Box Business
                'https://www.youtube.com/watch?v=yIojDj4W6_c'  // Common Subscription Box Challenges
            ];
            break;
        case 'personal-chef':
            businessText = 'Personal Chef or Catering Service';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=Y8gGBxV5wN0', // How to Start a Personal Chef Business
                'https://www.youtube.com/watch?v=sXZ-6jss3h4', // Catering Business Marketing Tips
                'https://www.youtube.com/watch?v=YxlXcP_2bnA', // Pricing Your Catering Services
                'https://www.youtube.com/watch?v=6xrPr73H3Yg', // Building Your Catering Portfolio
                'https://www.youtube.com/watch?v=4hd1IqVbE3Q'  // Common Catering Challenges
            ];
            break;
        case 'thrift-store':
            businessText = 'Vintage or Thrift Store';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=cKcr3kUd_9I', // Starting a Thrift Store
                'https://www.youtube.com/watch?v=4uED7vU_yTY', // Thrift Store Marketing Strategies
                'https://www.youtube.com/watch?v=7xG52S6Hp1Y', // Pricing for Thrift Stores
                'https://www.youtube.com/watch?v=E9BU8lb4n4M', // Managing a Thrift Store
                'https://www.youtube.com/watch?v=3cDAz5eGAPc'  // Common Thrift Store Challenges
            ];
            break;
        case 'yoga-instructor':
            businessText = 'Yoga or Meditation Instructor';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=pH6x3hYrM0Q', // Starting a Yoga Business
                'https://www.youtube.com/watch?v=FlCYNmvCZT0', // Yoga Marketing Strategies
                'https://www.youtube.com/watch?v=sXNWnqrBgG0', // Pricing Your Yoga Classes
                'https://www.youtube.com/watch?v=1_ynpwn8EV0', // Building Your Yoga Portfolio
                'https://www.youtube.com/watch?v=H9z70vW6h8c'  // Common Yoga Business Challenges
            ];
            break;
        case 'bnb':
            businessText = 'Bed and Breakfast (B&B)';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=3qgFknhRXZ0', // How to Start a B&B
                'https://www.youtube.com/watch?v=vHgs2U8rPhg', // B&B Marketing Tips
                'https://www.youtube.com/watch?v=3y8E-TGQU2Q', // Pricing Your B&B Services
                'https://www.youtube.com/watch?v=zzSZXcBi8xw', // Building Your B&B Brand
                'https://www.youtube.com/watch?v=kEn9Tp5ucAI'  // Common B&B Challenges
            ];
            break;
        case 'crafts':
            businessText = 'Crafts or Handmade Products Business';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=4bG0JECgRuw', // Starting a Crafts Business
                'https://www.youtube.com/watch?v=Nm-N5MH2L7s', // Marketing Handmade Products
                'https://www.youtube.com/watch?v=EfDWhX6rZpE', // Pricing Your Crafts
                'https://www.youtube.com/watch?v=0dHzzrc9ozw', // Building Your Crafts Portfolio
                'https://www.youtube.com/watch?v=8ZZYZH1htPM'  // Common Crafts Challenges
            ];
            break;
        case 'interior-design':
            businessText = 'Interior Design';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=6sZgZr0dKJs', // How to Start an Interior Design Business
                'https://www.youtube.com/watch?v=aG3RwtKN2NY', // Marketing Your Interior Design Services
                'https://www.youtube.com/watch?v=Buj0Mlk4xy4', // Pricing Your Interior Design Services
                'https://www.youtube.com/watch?v=V3hf67F8QOA', // Building Your Interior Design Portfolio
                'https://www.youtube.com/watch?v=tT4GBe4-btI'  // Common Interior Design Challenges
            ];
            break;
        case 'translation':
            businessText = 'Translation or Interpretation Services';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=3rWi5_XO4yo', // Starting a Translation Business
                'https://www.youtube.com/watch?v=dSvh5EkTT0U', // Marketing Translation Services
                'https://www.youtube.com/watch?v=s1nxM4ewlXY', // Pricing Your Translation Services
                'https://www.youtube.com/watch?v=pO0aUm0U48s', // Building Your Translation Portfolio
                'https://www.youtube.com/watch?v=Tm30swTY5to'  // Common Translation Challenges
            ];
            break;
        case 'photography':
            businessText = 'Photography';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=6S9xi5lv6H4', // How to Start a Photography Business
                'https://www.youtube.com/watch?v=aD7aD8XYPPc', // Photography Marketing Tips
                'https://www.youtube.com/watch?v=9GVzxRCeiyU', // Pricing Your Photography Services
                'https://www.youtube.com/watch?v=lTQApnPVRQo', // Building Your Photography Portfolio
                'https://www.youtube.com/watch?v=6GvsnKAH3Ms'  // Common Photography Challenges
            ];
            break;
        case 'fitness-trainer':
            businessText = 'Fitness Trainer or Coach';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=rbTVNqFRbHk', // How to Start a Fitness Training Business
                'https://www.youtube.com/watch?v=ttOgP0r2zM4', // Fitness Training Marketing Strategies
                'https://www.youtube.com/watch?v=BZUkQ-L-kaw', // Pricing Your Fitness Training Services
                'https://www.youtube.com/watch?v=ZW5wd62jUtQ', // Building Your Fitness Training Portfolio
                'https://www.youtube.com/watch?v=FvqaE54nP6Q'  // Common Fitness Training Challenges
            ];
            break;
        case 'web-design':
            businessText = 'Web Design or Development';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=AySS03jBz7g', // Starting a Web Design Business
                'https://www.youtube.com/watch?v=OaqKD6XJtYY', // Web Design Marketing Strategies
                'https://www.youtube.com/watch?v=3Y5DQ_xMBNk', // Pricing Your Web Design Services
                'https://www.youtube.com/watch?v=4Cnb3mElNHM', // Building Your Web Design Portfolio
                'https://www.youtube.com/watch?v=t8m0RQKe2pE'  // Common Web Design Challenges
            ];
            break;
        case 'ecommerce':
            businessText = 'E-commerce or Online Store';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=2IuWkA4W4pI', // How to Start an E-commerce Business
                'https://www.youtube.com/watch?v=2hPyaQ4Vt2Y', // E-commerce Marketing Strategies
                'https://www.youtube.com/watch?v=5plfL8wdMK4', // Pricing Your E-commerce Products
                'https://www.youtube.com/watch?v=5fpuk8lh-O4', // Building Your E-commerce Store
                'https://www.youtube.com/watch?v=NZcIC1r0JVE'  // Common E-commerce Challenges
            ];
            break;
        case 'event-planning':
            businessText = 'Event Planning';
            youtubeLinks = [
                'https://www.youtube.com/watch?v=1yKIp_2KMAs', // How to Start an Event Planning Business
                'https://www.youtube.com/watch?v=5VZ8nQ6Nmwo', // Event Planning Marketing Tips
                'https://www.youtube.com/watch?v=5HDwL-tKScU', // Pricing Your Event Planning Services
                'https://www.youtube.com/watch?v=xPZyA9xfnkg', // Building Your Event Planning Portfolio
                'https://www.youtube.com/watch?v=52q7MvRHRW4'  // Common Event Planning Challenges
            ];
            break;
        default:
            businessText = 'Unknown Business Type';
            youtubeLinks = [];
            break;
    }

    // Display the YouTube links
    if (youtubeLinks) {
        youtubeLinks.forEach(link => {
            const listItem = document.createElement('li');
            listItem.innerHTML = `<a href="${link}" target="_blank">${link}</a>`;
            videoLinksList.appendChild(listItem);
        });
    }
});
